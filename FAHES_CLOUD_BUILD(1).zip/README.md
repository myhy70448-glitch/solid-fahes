# FAHES – فاحص

نواة تطبيق Flutter لفحص وتشخيص السيارات.

## التشغيل
1. ثبّت Flutter.
2. افتح المجلد.
3. نفّذ:
   flutter pub get
   flutter run

## الموجود حاليًا
- واجهة عربية RTL.
- الرئيسية.
- شاشة تشخيص أولي.
- طبقة خدمة DiagnosisService قابلة للربط بواجهة AI حقيقية.
- طبقة OBDService قابلة للربط ببلوتوث/OBD2 حقيقي.
- غرفة الإعلانات.
- الحساب وسجل الخدمات كواجهات أولية.

## الخطوات الإنتاجية التالية
- Firebase Authentication.
- Firestore/Storage.
- API آمن للذكاء الاصطناعي.
- Bluetooth OBD2 package ودعم الأجهزة الفعلية.
- Camera/Audio permissions.
- Maps وموقع المستخدم.
- نظام حسابات للمعلنين وباقات دفع.
- لوحة تحكم Admin.
- Localization عربي/إنجليزي.
- اختبار Android/iOS وإعداد Play Store.

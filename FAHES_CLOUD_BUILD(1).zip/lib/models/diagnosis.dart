class Diagnosis {
  final String title;
  final String severity;
  final int probability;
  final String explanation;
  final List<String> checks;

  const Diagnosis({
    required this.title,
    required this.severity,
    required this.probability,
    required this.explanation,
    required this.checks,
  });
}

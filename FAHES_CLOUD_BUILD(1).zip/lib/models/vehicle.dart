class Vehicle {
  final String make;
  final String model;
  final int year;
  final String engine;

  const Vehicle({
    required this.make,
    required this.model,
    required this.year,
    required this.engine,
  });
}

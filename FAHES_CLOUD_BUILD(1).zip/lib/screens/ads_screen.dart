import 'package:flutter/material.dart';

class AdsScreen extends StatelessWidget {
  const AdsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ads = [
      ('ورشة النخبة', 'صيانة وفحص سيارات', Icons.car_repair),
      ('قطع غيار المدينة', 'قطع غيار وإكسسوارات', Icons.settings),
      ('مركز الإطارات', 'إطارات وزيوت', Icons.tire_repair),
    ];

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('غرفة الإعلانات', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('خدمات ومنتجات السيارات حسب المدينة والتخصص.'),
          const SizedBox(height: 18),
          TextField(
            decoration: InputDecoration(
              hintText: 'ابحث عن ورشة أو قطعة غيار...',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: IconButton(icon: const Icon(Icons.tune), onPressed: () {}),
            ),
          ),
          const SizedBox(height: 18),
          ...ads.map((ad) => Card(
            elevation: 0,
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              leading: CircleAvatar(child: Icon(ad.$3)),
              title: Text(ad.$1, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(ad.$2),
              trailing: const Icon(Icons.chevron_left),
            ),
          )),
        ],
      ),
    );
  }
}

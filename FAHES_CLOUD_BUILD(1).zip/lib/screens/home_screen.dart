import 'package:flutter/material.dart';
import '../widgets/service_card.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('فاحص', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
          Text('FAHES • Smart Vehicle Diagnostics', style: TextStyle(color: Colors.grey.shade600)),
          const SizedBox(height: 22),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(26),
              color: const Color(0xFF087F7B),
            ),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.directions_car, color: Colors.white, size: 48),
              SizedBox(height: 14),
              Text('افحص سيارتك بذكاء', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
              SizedBox(height: 6),
              Text('أدخل الأعراض أو استخدم OBD2 للحصول على تحليل أولي.', style: TextStyle(color: Colors.white70)),
            ]),
          ),
          const SizedBox(height: 25),
          const Text('الخدمات', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            children: [
              ServiceCard(icon: Icons.smart_toy, title: 'تشخيص AI', onTap: () {}),
              ServiceCard(icon: Icons.camera_alt, title: 'تحليل الصور', onTap: () {}),
              ServiceCard(icon: Icons.graphic_eq, title: 'تحليل الصوت', onTap: () {}),
              ServiceCard(icon: Icons.bluetooth, title: 'OBD2', onTap: () {}),
            ],
          ),
          const SizedBox(height: 22),
          const Text('إعلان مميز', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Card(
            elevation: 0,
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.build)),
              title: const Text('ورشة أو متجر سيارات'),
              subtitle: const Text('مكان مخصص للإعلانات المدفوعة داخل فاحص'),
              trailing: const Icon(Icons.chevron_left),
            ),
          ),
        ]),
      ),
    );
  }
}

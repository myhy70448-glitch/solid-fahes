import 'package:flutter/material.dart';
import '../services/diagnosis_service.dart';
import '../services/obd_service.dart';
import '../models/diagnosis.dart';

class InspectionScreen extends StatefulWidget {
  const InspectionScreen({super.key});
  @override
  State<InspectionScreen> createState() => _InspectionScreenState();
}

class _InspectionScreenState extends State<InspectionScreen> {
  final symptoms = TextEditingController();
  final service = DiagnosisService();
  List<Diagnosis> results = [];
  bool loading = false;

  Future<void> diagnose() async {
    if (symptoms.text.trim().isEmpty) return;
    setState(() => loading = true);
    final data = await service.diagnose(symptoms: symptoms.text, vehicle: 'Unknown');
    setState(() {
      results = data;
      loading = false;
    });
  }

  Future<void> scanObd() async {
    final codes = await ObdService().scan();
    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          shrinkWrap: true,
          children: [
            const Text('نتيجة OBD2', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ...codes.map((e) => ListTile(leading: const Icon(Icons.error_outline), title: Text(e))),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('فحص السيارة', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('النتائج إرشادية ولا تغني عن فحص فني متخصص.'),
          const SizedBox(height: 20),
          TextField(
            controller: symptoms,
            maxLines: 5,
            decoration: const InputDecoration(
              hintText: 'اكتب الأعراض: السيارة لا تعمل، اهتزاز، صوت، حرارة...',
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: loading ? null : diagnose,
            icon: const Icon(Icons.psychology),
            label: Text(loading ? 'جاري التحليل...' : 'تشخيص بالذكاء الاصطناعي'),
          ),
          OutlinedButton.icon(
            onPressed: scanObd,
            icon: const Icon(Icons.bluetooth),
            label: const Text('فحص OBD2'),
          ),
          const SizedBox(height: 20),
          ...results.map((r) => Card(
            elevation: 0,
            margin: const EdgeInsets.only(bottom: 12),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(r.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('احتمال أولي: ${r.probability}% • الخطورة: ${r.severity}'),
                const SizedBox(height: 8),
                Text(r.explanation),
                const SizedBox(height: 10),
                const Text('فحوصات مقترحة:', style: TextStyle(fontWeight: FontWeight.bold)),
                ...r.checks.map((c) => Text('• $c')),
              ]),
            ),
          )),
        ],
      ),
    );
  }

  @override
  void dispose() {
    symptoms.dispose();
    super.dispose();
  }
}

import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const CircleAvatar(radius: 44, child: Icon(Icons.person, size: 45)),
          const SizedBox(height: 12),
          const Center(child: Text('حساب المستخدم', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
          const SizedBox(height: 25),
          Card(
            elevation: 0,
            child: Column(children: [
              ListTile(leading: const Icon(Icons.history), title: const Text('سجل الفحوصات'), onTap: () {}),
              ListTile(leading: const Icon(Icons.directions_car), title: const Text('سياراتي'), onTap: () {}),
              ListTile(leading: const Icon(Icons.settings), title: const Text('الإعدادات'), onTap: () {}),
            ]),
          ),
        ],
      ),
    );
  }
}

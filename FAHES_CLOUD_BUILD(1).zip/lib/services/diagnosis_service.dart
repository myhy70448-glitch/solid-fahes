import '../models/diagnosis.dart';

class DiagnosisService {
  Future<List<Diagnosis>> diagnose({
    required String symptoms,
    required String vehicle,
  }) async {
    await Future.delayed(const Duration(milliseconds: 700));

    return [
      Diagnosis(
        title: 'نظام الإشعال أو الوقود',
        severity: 'متوسط',
        probability: 72,
        explanation: 'الأعراض المدخلة قد تتوافق مع مشكلة في الإشعال أو وصول الوقود. هذا تحليل أولي وليس تشخيصًا نهائيًا.',
        checks: ['فحص البواجي', 'فحص الكويلات', 'قراءة أكواد OBD2', 'فحص ضغط الوقود'],
      ),
      Diagnosis(
        title: 'حساسات المحرك',
        severity: 'منخفض',
        probability: 38,
        explanation: 'قد تكون بعض الحساسات سببًا محتملًا إذا ظهرت لمبة المحرك أو تغير أداء المحرك.',
        checks: ['قراءة الأكواد', 'فحص حساس الهواء', 'فحص التوصيلات الكهربائية'],
      ),
    ];
  }
}

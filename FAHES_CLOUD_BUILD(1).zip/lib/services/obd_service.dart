class ObdService {
  Future<List<String>> scan() async {
    await Future.delayed(const Duration(seconds: 1));
    return ['P0300 - عشوائية/تعدد اختلالات الاشتعال', 'P0171 - خليط فقير'];
  }
}
